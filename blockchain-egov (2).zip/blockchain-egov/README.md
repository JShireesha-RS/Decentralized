# Decentralized E-Governance System

A blockchain-based government service system with secure, transparent, and immutable records management.

## Project Overview

This system implements a decentralized e-governance platform where:
- Citizens can apply for government services (certificates, land records, welfare schemes)
- Government authorities review and approve/reject requests
- All records are stored immutably on blockchain
- Data cannot be modified once approved
- Complete transparency and audit trail

## Problem Statement

Traditional e-governance systems have critical issues:
- **Centralized Vulnerabilities**: Single point of failure
- **Data Tampering**: Records can be modified by insiders
- **Lack of Transparency**: Unclear approval processes
- **Unverifiable Records**: Citizens cannot independently verify documents
- **Bureaucratic Delays**: Manual approval processes

## Solution: Blockchain-Based System

Our system uses blockchain technology to ensure:
- ✅ **Decentralization**: No single authority controls the data
- ✅ **Immutability**: Records cannot be changed once approved
- ✅ **Transparency**: All actions are traceable and visible
- ✅ **Security**: Cryptographic protection and authentication
- ✅ **Efficiency**: Smart contracts automate approvals

## System Architecture

```
┌─────────────────┐
│   Frontend      │  (HTML, CSS, JavaScript)
│  - Citizen      │  Web portal for citizens & authorities
│  - Authority    │
└────────┬────────┘
         │
┌────────▼────────┐
│  Backend        │  (Java Spring Boot)
│  - REST APIs    │  Business logic & database management
│  - Services     │
│  - Database     │
└────────┬────────┘
         │
┌────────▼────────┐
│  Blockchain     │  (Ethereum Smart Contracts)
│  - Smart Contracts │ Immutable record storage
│  - Transactions    │ Transaction verification
└─────────────────┘
```

## Features

### Citizen Module
- ✔ User registration with blockchain wallet
- ✔ Submit service requests (CERTIFICATE, LAND_RECORD, WELFARE_SCHEME)
- ✔ Track application status in real-time
- ✔ Verify issued records on blockchain
- ✔ View complete transaction history

### Government Authority Module
- ✔ Official login and authentication
- ✔ View pending citizen requests
- ✔ Approve or reject with detailed comments
- ✔ Record decisions on blockchain
- ✔ Access request history and statistics

### Blockchain Module
- ✔ Immutable record storage with smart contracts
- ✔ Transaction verification and validation
- ✔ Decentralized ledger maintenance
- ✔ Public record verification

## Technology Stack

| Component | Technology |
|-----------|------------|
| Frontend | HTML5, CSS3, JavaScript (ES6+) |
| Backend | Java 8, Spring Boot 2.7 |
| Database | H2 (Development), PostgreSQL (Production) |
| Blockchain | Ethereum, Solidity |
| Web3 Integration | Web3.js, MetaMask |
| Build Tool | Maven |
| REST Framework | Spring Data JPA |

## Installation & Setup

### Prerequisites
- Java 8 or higher
- Maven 3.6+
- Node.js (for blockchain development)
- MetaMask browser extension

### Backend Setup

1. Navigate to project directory:
```bash
cd blockchain-egov
```

2. Install Maven dependencies:
```bash
mvn clean install
```

3. Compile the project:
```bash
mvn clean compile
```

4. Run the Spring Boot application:
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080/egov`

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Open `index.html` in a web browser or use a local server:
```bash
# Using Python
python -m http.server 3000

# Or using Node.js http-server
http-server -p 3000
```

3. Access the application at `http://localhost:3000`

## API Endpoints

### User Management
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - Login to system
- `GET /api/users/{id}` - Get user information
- `GET /api/users/username/{username}` - Search by username

### Service Requests
- `POST /api/requests/submit` - Submit service request
- `GET /api/requests/{id}` - Get request details
- `GET /api/requests/citizen/{citizenId}` - Get citizen's requests
- `GET /api/requests/pending` - Get all pending requests
- `GET /api/requests/requestId/{requestId}` - Search by request ID

### Approvals
- `POST /api/approvals/approve` - Approve request
- `POST /api/approvals/reject` - Reject request
- `GET /api/approvals/request/{requestId}` - Get approvals for request
- `GET /api/approvals/authority/{authorityId}` - Get authority's approvals

## Usage Example

### 1. Register as Citizen
```javascript
// POST /api/users/register?username=john&password=pass123&email=john@email.com&fullName=John Doe&role=CITIZEN
```

### 2. Submit Service Request
```javascript
// POST /api/requests/submit?citizenId=1&serviceType=CERTIFICATE&description=Birth Certificate Request
```

### 3. Authority Approves Request
```javascript
// POST /api/approvals/approve?requestId=1&authorityId=2&comments=Document verified
```

### 4. Verify on Blockchain
```javascript
// GET /api/requests/requestId/{requestId}
// Check blockchainHash field
```

## Database Schema

### Users Table
```
id (PK)
username (UNIQUE)
password
email
fullName
role (ENUM: CITIZEN, AUTHORITY, ADMIN)
walletAddress
createdAt
active
```

### ServiceRequests Table
```
id (PK)
requestId (UNIQUE)
citizenId (FK)
serviceType (ENUM: CERTIFICATE, LAND_RECORD, WELFARE_SCHEME)
description
status (ENUM: PENDING, APPROVED, REJECTED)
blockchainHash
createdAt
updatedAt
```

### Approvals Table
```
id (PK)
requestId (FK)
authorityId (FK)
comments
decision (ENUM: APPROVED, REJECTED)
blockchainHash
createdAt
```

## Smart Contract Functions

The Solidity smart contract includes:

```solidity
// User Management
registerUser(username, role)

// Request Management
submitRequest(requestId, serviceType, description)
getRequest(requestId)
getRequestByRequestId(requestString)

// Approval Process
approveRequest(requestId, comments)
rejectRequest(requestId, comments)
getApprovals(requestId)

// Verification
verifyRecord(requestId)
getTotalRequests()
```

## Security Features

1. **Authentication**
   - Username/password authentication
   - Blockchain wallet verification with MetaMask

2. **Authorization**
   - Role-based access control (CITIZEN, AUTHORITY, ADMIN)
   - Function-level permissions

3. **Data Protection**
   - Cryptographic hashing of sensitive data
   - Encrypted wallet addresses
   - HTTPS for API communications (production)

4. **Blockchain Security**
   - Smart contract validation
   - Transaction signing with private keys
   - Immutable audit trail

## System Flow

```
1. Citizen Registration
   ├─ User creates account with wallet
   └─ System generates wallet address

2. Service Request Submission
   ├─ Citizen fills request form
   ├─ Request stored in database
   ├─ Transaction sent to blockchain
   └─ Unique request ID generated

3. Authority Review
   ├─ Authority views pending requests
   ├─ Reviews documents and details
   └─ Makes approval/rejection decision

4. Blockchain Recording
   ├─ Decision sent to smart contract
   ├─ Smart contract validates
   ├─ Transaction mined on blockchain
   └─ Immutable record created

5. Citizen Notification
   ├─ Citizen receives status update
   ├─ Can verify record on blockchain
   └─ Record cannot be modified
```

## Testing

Run unit tests:
```bash
mvn test
```

Build the project:
```bash
mvn clean package
```

## Project Structure

```
blockchain-egov/
├── src/
│   ├── main/
│   │   ├── java/com/gandham/egov/
│   │   │   ├── App.java (Main Spring Boot class)
│   │   │   ├── controller/ (REST controllers)
│   │   │   ├── service/ (Business logic)
│   │   │   ├── repository/ (Data access)
│   │   │   ├── model/ (Entity classes)
│   │   │   └── dto/ (Data Transfer Objects)
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/com/gandham/egov/
├── frontend/
│   ├── index.html (Home page)
│   ├── login.html (Login/Register)
│   ├── citizen-dashboard.html
│   ├── authority-dashboard.html
│   ├── about.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── api.js (API communication)
│       ├── auth.js (Authentication)
│       ├── citizen.js (Citizen dashboard)
│       └── authority.js (Authority dashboard)
├── smart-contracts/
│   └── EGovernance.sol (Smart contract)
├── pom.xml
└── README.md
```

## Configuration

Edit `application.properties` to customize:
- Server port (default: 8080)
- Database settings
- Logging levels
- Application name and version

## Advantages

✅ **Prevents Corruption**: Immutable records prevent insider manipulation
✅ **Increases Transparency**: All actions are traceable and visible
✅ **Builds Trust**: Citizens can independently verify records
✅ **Reduces Delays**: Smart contracts automate approvals
✅ **Cost Efficient**: Eliminates intermediaries
✅ **Scalable**: Blockchain can handle growing records

## Limitations

⚠️ **Blockchain Speed**: Slower than centralized databases
⚠️ **Scalability**: Limited transaction throughput
⚠️ **Complexity**: Technical knowledge required
⚠️ **Storage Cost**: Higher operational costs
⚠️ **Regulations**: Legal framework still developing

## Future Enhancements

- 📱 Mobile application (iOS/Android)
- 🤖 AI-based fraud detection
- 📄 IPFS for document storage
- 🏛️ National ID integration
- 🌍 Inter-state/international interoperability
- ⚡ Layer-2 scaling solutions
- 🗣️ Multi-language support
- 📊 Advanced analytics dashboard

## Support & Documentation

For detailed information, see:
- **Project Report**: [Complete documentation]
- **API Documentation**: Available via Swagger (planned)
- **Smart Contract Docs**: See `smart-contracts/` directory

## License

This project is for educational purposes. Deployment for production requires legal approval.

## Authors

- Student Project Team
- Decentralized E-Governance System 2024-2025

## Acknowledgments

- Spring Boot Framework
- Ethereum Blockchain
- Web3.js Library
- MetaMask Wallet

---

**Last Updated**: February 6, 2025
**Version**: 1.0.0
