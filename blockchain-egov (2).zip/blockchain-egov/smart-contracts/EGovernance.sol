// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * Decentralized E-Governance Smart Contract
 * Manages service requests, approvals, and records on blockchain
 */
contract EGovernance {
    
    // Enums for status
    enum RequestStatus { PENDING, APPROVED, REJECTED }
    
    // Struct for Service Request
    struct ServiceRequest {
        uint256 id;
        string requestId;
        address citizen;
        string serviceType;
        string description;
        RequestStatus status;
        uint256 createdAt;
        uint256 updatedAt;
    }
    
    // Struct for Approval
    struct Approval {
        uint256 id;
        uint256 requestId;
        address authority;
        string comments;
        RequestStatus decision;
        uint256 timestamp;
    }
    
    // Struct for User
    struct UserRecord {
        address walletAddress;
        string username;
        string role; // CITIZEN, AUTHORITY, ADMIN
        uint256 registeredAt;
    }
    
    // State variables
    mapping(uint256 => ServiceRequest) public requests;
    mapping(uint256 => Approval[]) public approvals;
    mapping(address => UserRecord) public users;
    mapping(string => uint256) public requestIdToIndex;
    
    uint256 public requestCounter = 0;
    uint256 public approvalCounter = 0;
    
    address public admin;
    
    // Events
    event RequestSubmitted(uint256 indexed requestId, address indexed citizen, string serviceType);
    event RequestApproved(uint256 indexed requestId, address indexed authority);
    event RequestRejected(uint256 indexed requestId, address indexed authority);
    event UserRegistered(address indexed walletAddress, string username, string role);
    
    // Constructor
    constructor() {
        admin = msg.sender;
    }
    
    // Register user on blockchain
    function registerUser(string memory username, string memory role) public {
        require(bytes(username).length > 0, "Username cannot be empty");
        require(bytes(role).length > 0, "Role cannot be empty");
        
        users[msg.sender] = UserRecord({
            walletAddress: msg.sender,
            username: username,
            role: role,
            registeredAt: block.timestamp
        });
        
        emit UserRegistered(msg.sender, username, role);
    }
    
    // Submit service request
    function submitRequest(
        string memory requestId,
        string memory serviceType,
        string memory description
    ) public {
        require(bytes(requestId).length > 0, "Request ID cannot be empty");
        require(bytes(serviceType).length > 0, "Service type cannot be empty");
        require(bytes(description).length > 0, "Description cannot be empty");
        
        requestCounter++;
        
        requests[requestCounter] = ServiceRequest({
            id: requestCounter,
            requestId: requestId,
            citizen: msg.sender,
            serviceType: serviceType,
            description: description,
            status: RequestStatus.PENDING,
            createdAt: block.timestamp,
            updatedAt: block.timestamp
        });
        
        requestIdToIndex[requestId] = requestCounter;
        
        emit RequestSubmitted(requestCounter, msg.sender, serviceType);
    }
    
    // Get request details
    function getRequest(uint256 requestId) public view returns (ServiceRequest memory) {
        require(requestId > 0 && requestId <= requestCounter, "Invalid request ID");
        return requests[requestId];
    }
    
    // Get request by requestId string
    function getRequestByRequestId(string memory requestId) public view returns (ServiceRequest memory) {
        uint256 index = requestIdToIndex[requestId];
        require(index > 0, "Request not found");
        return requests[index];
    }
    
    // Approve request (only authority)
    function approveRequest(uint256 requestId, string memory comments) public {
        require(requestId > 0 && requestId <= requestCounter, "Invalid request ID");
        require(bytes(users[msg.sender].role).length > 0, "User not registered");
        
        ServiceRequest storage request = requests[requestId];
        require(request.status == RequestStatus.PENDING, "Request is not pending");
        
        request.status = RequestStatus.APPROVED;
        request.updatedAt = block.timestamp;
        
        Approval memory approval = Approval({
            id: approvalCounter++,
            requestId: requestId,
            authority: msg.sender,
            comments: comments,
            decision: RequestStatus.APPROVED,
            timestamp: block.timestamp
        });
        
        approvals[requestId].push(approval);
        
        emit RequestApproved(requestId, msg.sender);
    }
    
    // Reject request (only authority)
    function rejectRequest(uint256 requestId, string memory comments) public {
        require(requestId > 0 && requestId <= requestCounter, "Invalid request ID");
        require(bytes(users[msg.sender].role).length > 0, "User not registered");
        
        ServiceRequest storage request = requests[requestId];
        require(request.status == RequestStatus.PENDING, "Request is not pending");
        
        request.status = RequestStatus.REJECTED;
        request.updatedAt = block.timestamp;
        
        Approval memory approval = Approval({
            id: approvalCounter++,
            requestId: requestId,
            authority: msg.sender,
            comments: comments,
            decision: RequestStatus.REJECTED,
            timestamp: block.timestamp
        });
        
        approvals[requestId].push(approval);
        
        emit RequestRejected(requestId, msg.sender);
    }
    
    // Get approvals for a request
    function getApprovals(uint256 requestId) public view returns (Approval[] memory) {
        return approvals[requestId];
    }
    
    // Verify record on blockchain
    function verifyRecord(string memory requestId) public view returns (bool) {
        uint256 index = requestIdToIndex[requestId];
        if (index == 0) return false;
        
        ServiceRequest memory request = requests[index];
        return request.status == RequestStatus.APPROVED;
    }
    
    // Get total requests count
    function getTotalRequests() public view returns (uint256) {
        return requestCounter;
    }
}
