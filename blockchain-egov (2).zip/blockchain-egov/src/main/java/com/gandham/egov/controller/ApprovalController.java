package com.gandham.egov.controller;

import com.gandham.egov.model.Approval;
import com.gandham.egov.service.ApprovalService;
import com.gandham.egov.service.ServiceRequestService;
import com.gandham.egov.model.RequestStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/approvals")
@CrossOrigin(origins = "*")
public class ApprovalController {

    @Autowired
    private ApprovalService approvalService;

    @Autowired
    private ServiceRequestService serviceRequestService;

    @PostMapping("/approve")
    public ResponseEntity<Map<String, Object>> approveRequest(@RequestParam Long requestId,
                                                              @RequestParam Long authorityId,
                                                              @RequestParam(required = false) String comments) {
        try {
            Approval approval = approvalService.approveRequest(requestId, authorityId, comments != null ? comments : "");
            serviceRequestService.updateRequestStatus(requestId, RequestStatus.APPROVED);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Request approved successfully");
            response.put("approvalId", approval.getId());
            response.put("requestId", approval.getRequestId());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/reject")
    public ResponseEntity<Map<String, Object>> rejectRequest(@RequestParam Long requestId,
                                                             @RequestParam Long authorityId,
                                                             @RequestParam(required = false) String comments) {
        try {
            Approval approval = approvalService.rejectRequest(requestId, authorityId, comments != null ? comments : "");
            serviceRequestService.updateRequestStatus(requestId, RequestStatus.REJECTED);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Request rejected successfully");
            response.put("approvalId", approval.getId());
            response.put("requestId", approval.getRequestId());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/request/{requestId}")
    public ResponseEntity<List<Approval>> getApprovalsByRequest(@PathVariable Long requestId) {
        List<Approval> approvals = approvalService.getApprovalsByRequest(requestId);
        return ResponseEntity.ok(approvals);
    }

    @GetMapping("/authority/{authorityId}")
    public ResponseEntity<List<Approval>> getApprovalsByAuthority(@PathVariable Long authorityId) {
        List<Approval> approvals = approvalService.getApprovalsByAuthority(authorityId);
        return ResponseEntity.ok(approvals);
    }
}
