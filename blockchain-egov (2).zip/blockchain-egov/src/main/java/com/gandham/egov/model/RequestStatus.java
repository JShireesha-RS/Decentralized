package com.gandham.egov.model;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
