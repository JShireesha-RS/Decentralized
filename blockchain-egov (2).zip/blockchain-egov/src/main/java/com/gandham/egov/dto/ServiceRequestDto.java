package com.gandham.egov.dto;

public class ServiceRequestDto {
    private Long id;
    private String requestId;
    private Long citizenId;
    private String serviceType;
    private String description;
    private String status;
    private String blockchainHash;
    private Long createdAt;

    public ServiceRequestDto() {}
    public ServiceRequestDto(Long id, String requestId, Long citizenId, String serviceType, String description, String status, String blockchainHash, Long createdAt) {
        this.id = id;
        this.requestId = requestId;
        this.citizenId = citizenId;
        this.serviceType = serviceType;
        this.description = description;
        this.status = status;
        this.blockchainHash = blockchainHash;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }

    public Long getCitizenId() { return citizenId; }
    public void setCitizenId(Long citizenId) { this.citizenId = citizenId; }

    public String getServiceType() { return serviceType; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getBlockchainHash() { return blockchainHash; }
    public void setBlockchainHash(String blockchainHash) { this.blockchainHash = blockchainHash; }

    public Long getCreatedAt() { return createdAt; }
    public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
