package com.gandham.egov.dto;

public class ApprovalDto {
    private Long id;
    private Long requestId;
    private Long authorityId;
    private String comments;
    private String decision;
    private String blockchainHash;

    public ApprovalDto() {}
    public ApprovalDto(Long id, Long requestId, Long authorityId, String comments, String decision, String blockchainHash) {
        this.id = id;
        this.requestId = requestId;
        this.authorityId = authorityId;
        this.comments = comments;
        this.decision = decision;
        this.blockchainHash = blockchainHash;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }

    public Long getAuthorityId() { return authorityId; }
    public void setAuthorityId(Long authorityId) { this.authorityId = authorityId; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }

    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }

    public String getBlockchainHash() { return blockchainHash; }
    public void setBlockchainHash(String blockchainHash) { this.blockchainHash = blockchainHash; }
}
