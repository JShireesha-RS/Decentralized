package com.gandham.egov.service;

import com.gandham.egov.model.Approval;
import com.gandham.egov.model.RequestStatus;
import com.gandham.egov.repository.ApprovalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApprovalService {

    @Autowired
    private ApprovalRepository approvalRepository;

    public Approval approveRequest(Long requestId, Long authorityId, String comments) {
        Approval approval = new Approval();
        approval.setRequestId(requestId);
        approval.setAuthorityId(authorityId);
        approval.setComments(comments);
        approval.setDecision(RequestStatus.APPROVED);
        approval.setCreatedAt(System.currentTimeMillis());
        return approvalRepository.save(approval);
    }

    public Approval rejectRequest(Long requestId, Long authorityId, String comments) {
        Approval approval = new Approval();
        approval.setRequestId(requestId);
        approval.setAuthorityId(authorityId);
        approval.setComments(comments);
        approval.setDecision(RequestStatus.REJECTED);
        approval.setCreatedAt(System.currentTimeMillis());
        return approvalRepository.save(approval);
    }

    public List<Approval> getApprovalsByRequest(Long requestId) {
        return approvalRepository.findByRequestId(requestId);
    }

    public List<Approval> getApprovalsByAuthority(Long authorityId) {
        return approvalRepository.findByAuthorityId(authorityId);
    }

    public Approval updateBlockchainHash(Long id, String hash) {
        Approval approval = approvalRepository.findById(id).orElse(null);
        if (approval != null) {
            approval.setBlockchainHash(hash);
            return approvalRepository.save(approval);
        }
        return null;
    }
}
