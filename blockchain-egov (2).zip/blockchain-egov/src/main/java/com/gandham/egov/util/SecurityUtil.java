package com.gandham.egov.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Security Utility for password hashing and validation
 * Uses SHA-256 with salt for password hashing
 */
public class SecurityUtil {
    
    /**
     * Hash password with salt using SHA-256
     * This is a simplified version - for production, use BCrypt
     */
    public static String hashPassword(String password) {
        try {
            // Generate salt
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);
            
            // Hash password with salt
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(password.getBytes());
            
            // Combine salt and hash
            byte[] saltAndHash = new byte[salt.length + hashedPassword.length];
            System.arraycopy(salt, 0, saltAndHash, 0, salt.length);
            System.arraycopy(hashedPassword, 0, saltAndHash, salt.length, hashedPassword.length);
            
            // Encode to Base64
            return Base64.getEncoder().encodeToString(saltAndHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }
    
    /**
     * Verify password against hash
     */
    public static boolean verifyPassword(String password, String hash) {
        try {
            // Decode Base64
            byte[] saltAndHash = Base64.getDecoder().decode(hash);
            
            // Extract salt
            byte[] salt = new byte[16];
            System.arraycopy(saltAndHash, 0, salt, 0, 16);
            
            // Hash the provided password with the extracted salt
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(password.getBytes());
            
            // Compare hashes - simple byte-by-byte comparison
            byte[] storedHash = new byte[saltAndHash.length - 16];
            System.arraycopy(saltAndHash, 16, storedHash, 0, saltAndHash.length - 16);
            
            boolean passwordMatch = MessageDigest.isEqual(hashedPassword, storedHash);
            
            return passwordMatch;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid password hash format", e);
        }
    }
    
    /**
     * Generate a secure random token
     */
    public static String generateSecureToken() {
        byte[] randomBytes = new byte[32];
        new SecureRandom().nextBytes(randomBytes);
        return Base64.getEncoder().encodeToString(randomBytes);
    }
    
    /**
     * Mask sensitive data (e.g., Aadhaar, phone)
     */
    public static String maskData(String data) {
        if (data == null || data.length() <= 4) {
            return data;
        }
        String masked = data.substring(0, 2) + "*".repeat(data.length() - 4) + data.substring(data.length() - 2);
        return masked;
    }
}
