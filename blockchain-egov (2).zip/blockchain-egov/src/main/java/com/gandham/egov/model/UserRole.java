package com.gandham.egov.model;

public enum UserRole {
    CITIZEN,
    AUTHORITY,
    ADMIN
}
