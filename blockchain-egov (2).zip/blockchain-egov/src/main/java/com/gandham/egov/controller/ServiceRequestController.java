package com.gandham.egov.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gandham.egov.dto.ServiceRequestDto;
import com.gandham.egov.model.ServiceRequest;
import com.gandham.egov.service.ServiceRequestService;

@RestController
@RequestMapping("/api/requests")
@CrossOrigin(origins = "*")
public class ServiceRequestController {

    @Autowired
    private ServiceRequestService serviceRequestService;

    @PostMapping("/submit")
    public ResponseEntity<Map<String, Object>> submitRequest(@RequestParam Long citizenId,
                                                             @RequestParam String serviceType,
                                                             @RequestParam String description) {
        try {
            ServiceRequest request = serviceRequestService.submitRequest(citizenId, serviceType, description);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Service request submitted successfully");
            response.put("requestId", request.getRequestId());
            response.put("id", request.getId());
            response.put("status", request.getStatus().toString());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceRequestDto> getRequest(@PathVariable Long id) {
        Optional<ServiceRequest> request = serviceRequestService.getRequestById(id);
        if (request.isPresent()) {
            ServiceRequestDto dto = mapToDto(request.get());
            return ResponseEntity.ok(dto);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/requestId/{requestId}")
    public ResponseEntity<ServiceRequestDto> getRequestByRequestId(@PathVariable String requestId) {
        Optional<ServiceRequest> request = serviceRequestService.getRequestByRequestId(requestId);
        if (request.isPresent()) {
            ServiceRequestDto dto = mapToDto(request.get());
            return ResponseEntity.ok(dto);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/citizen/{citizenId}")
    public ResponseEntity<List<ServiceRequest>> getCitizenRequests(@PathVariable Long citizenId) {
        List<ServiceRequest> requests = serviceRequestService.getRequestsByCitizen(citizenId);
        return ResponseEntity.ok(requests);
    }

    @GetMapping("/pending")
    public ResponseEntity<List<ServiceRequest>> getPendingRequests() {
        List<ServiceRequest> requests = serviceRequestService.getPendingRequests();
        return ResponseEntity.ok(requests);
    }

    private ServiceRequestDto mapToDto(ServiceRequest request) {
        ServiceRequestDto dto = new ServiceRequestDto();
        dto.setId(request.getId());
        dto.setRequestId(request.getRequestId());
        dto.setCitizenId(request.getCitizenId());
        dto.setServiceType(request.getServiceType());
        dto.setDescription(request.getDescription());
        dto.setStatus(request.getStatus().toString());
        dto.setBlockchainHash(request.getBlockchainHash());
        dto.setCreatedAt(request.getCreatedAt());
        return dto;
    }
}
