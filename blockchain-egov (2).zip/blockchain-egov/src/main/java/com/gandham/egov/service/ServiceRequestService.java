package com.gandham.egov.service;

import com.gandham.egov.model.ServiceRequest;
import com.gandham.egov.model.RequestStatus;
import com.gandham.egov.repository.ServiceRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ServiceRequestService {

    @Autowired
    private ServiceRequestRepository serviceRequestRepository;

    public ServiceRequest submitRequest(Long citizenId, String serviceType, String description) {
        ServiceRequest request = new ServiceRequest();
        request.setRequestId(UUID.randomUUID().toString());
        request.setCitizenId(citizenId);
        request.setServiceType(serviceType);
        request.setDescription(description);
        request.setStatus(RequestStatus.PENDING);
        request.setCreatedAt(System.currentTimeMillis());
        request.setUpdatedAt(System.currentTimeMillis());
        return serviceRequestRepository.save(request);
    }

    public Optional<ServiceRequest> getRequestById(Long id) {
        return serviceRequestRepository.findById(id);
    }

    public Optional<ServiceRequest> getRequestByRequestId(String requestId) {
        return serviceRequestRepository.findByRequestId(requestId);
    }

    public List<ServiceRequest> getRequestsByCitizen(Long citizenId) {
        return serviceRequestRepository.findByCitizenId(citizenId);
    }

    public List<ServiceRequest> getPendingRequests() {
        return serviceRequestRepository.findByStatus(RequestStatus.PENDING);
    }

    public ServiceRequest updateRequestStatus(Long id, RequestStatus status) {
        Optional<ServiceRequest> request = serviceRequestRepository.findById(id);
        if (request.isPresent()) {
            request.get().setStatus(status);
            request.get().setUpdatedAt(System.currentTimeMillis());
            return serviceRequestRepository.save(request.get());
        }
        return null;
    }

    public ServiceRequest updateBlockchainHash(Long id, String hash) {
        Optional<ServiceRequest> request = serviceRequestRepository.findById(id);
        if (request.isPresent()) {
            request.get().setBlockchainHash(hash);
            return serviceRequestRepository.save(request.get());
        }
        return null;
    }
}
