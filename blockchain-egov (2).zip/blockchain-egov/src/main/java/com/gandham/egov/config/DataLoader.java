package com.gandham.egov.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Data loader for sample test data
 * Note: Sample data loading disabled due to model compatibility
 * Users must register manually or use provided sample credentials
 */
@Configuration
@Profile("dev")
public class DataLoader implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        System.out.println("===================================================");
        System.out.println("Decentralized E-Governance System - Dev Profile");
        System.out.println("===================================================");
        System.out.println("Backend API: http://localhost:8080/egov/api");
        System.out.println("H2 Console: http://localhost:8080/egov/h2-console");
        System.out.println("\nSample Test Credentials (register manually):");
        System.out.println("Citizen: email=citizen@test.com, password=pass123");
        System.out.println("Officer: email=officer@gov.in, password=pass123");
        System.out.println("Admin: email=admin@gov.in, password=pass123");
        System.out.println("===================================================\n");
    }
}

