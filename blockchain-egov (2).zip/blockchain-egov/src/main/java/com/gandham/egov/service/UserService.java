package com.gandham.egov.service;

import com.gandham.egov.model.User;
import com.gandham.egov.model.UserRole;
import com.gandham.egov.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(String username, String password, String email, String fullName, String role) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password); // In production, use BCryptPasswordEncoder
        user.setEmail(email);
        user.setFullName(fullName);
        user.setRole(UserRole.valueOf(role.toUpperCase()));
        user.setWalletAddress(UUID.randomUUID().toString()); // Simulated wallet
        return userRepository.save(user);
    }

    public Optional<User> login(String username, String password) {
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user;
        }
        return Optional.empty();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User updateUser(User user) {
        return userRepository.save(user);
    }
}
