package com.gandham.egov.repository;

import com.gandham.egov.model.ServiceRequest;
import com.gandham.egov.model.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, Long> {
    Optional<ServiceRequest> findByRequestId(String requestId);
    List<ServiceRequest> findByCitizenId(Long citizenId);
    List<ServiceRequest> findByStatus(RequestStatus status);
}
