package com.gandham.egov.repository;

import com.gandham.egov.model.Approval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApprovalRepository extends JpaRepository<Approval, Long> {
    List<Approval> findByRequestId(Long requestId);
    List<Approval> findByAuthorityId(Long authorityId);
}
