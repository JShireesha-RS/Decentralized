// Authority Dashboard Functions - Enhanced Version

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return;
    }

    const session = getSession();
    
    // Verify user is an authority
    if (session.role !== 'AUTHORITY' && session.role !== 'ADMIN') {
        alert('Access denied. Authority access only.');
        window.location.href = 'index.html';
        return;
    }

    document.getElementById('user-name').innerHTML = `<i class="fas fa-user-tie"></i> ${session.username}`;
    document.getElementById('wallet-address').textContent = session.walletAddress || '0x...';

    // Load initial dashboard data
    loadAuthorityDashboardData();
});

function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.remove('active'));

    // Remove active class from all sidebar links  
    const sidebarLinks = document.querySelectorAll('.sidebar a');
    sidebarLinks.forEach(link => link.classList.remove('active'));

    // Show selected section
    const sectionId = sectionName === 'dashboard' ? 'dashboard-section' : sectionName + '-section';
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.add('active');
    }

    // Add active class to currently clicked link
    if (event && event.target && event.target.classList) {
        event.target.classList.add('active');
    }

    // Load data based on section
    if (sectionName === 'pending') {
        loadPendingRequests();
    } else if (sectionName === 'approved') {
        loadApprovedRequests();
    } else if (sectionName === 'rejected') {
        loadRejectedRequests();
    }
}

async function loadAuthorityDashboardData() {
    try {
        const allRequests = await apiCall('GET', '/api/requests/pending');
        
        const pending = allRequests.filter(r => r.status === 'PENDING').length || 0;
        const approved = allRequests.filter(r => r.status === 'APPROVED').length || 0;
        const rejected = allRequests.filter(r => r.status === 'REJECTED').length || 0;

        document.getElementById('pending-count').textContent = pending;
        document.getElementById('approved-count').textContent = approved;
        document.getElementById('rejected-count').textContent = rejected;
        document.getElementById('total-processed').textContent = (pending + approved + rejected);
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

async function loadPendingRequests() {
    const tableBody = document.getElementById('pending-table');

    try {
        const requests = await apiCall('GET', '/api/requests/pending');

        if (!requests || requests.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 2rem; color: #9ca3af;">
                        <i class="fas fa-check"></i> No pending requests
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        requests.forEach(request => {
            const date = new Date(request.createdAt).toLocaleDateString();

            html += `
                <tr>
                    <td><strong>${request.requestId}</strong></td>
                    <td>Citizen ${request.citizenId}</td>
                    <td>${request.serviceType}</td>
                    <td>${date}</td>
                    <td>
                        <button class="btn btn-success btn-sm" onclick="openApprovalModal(${request.id}, '${request.requestId}')">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="openRejectionModal(${request.id}, '${request.requestId}')">
                            <i class="fas fa-times"></i> Reject
                        </button>
                    </td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;
    } catch (error) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5">
                    <p style="color: var(--danger-red); text-align: center;">
                        <i class="fas fa-exclamation-circle"></i> Error loading requests
                    </p>
                </td>
            </tr>
        `;
        console.error('Error:', error);
    }
}

async function loadApprovedRequests() {
    const tableBody = document.getElementById('approved-table');

    try {
        const allRequests = await apiCall('GET', '/api/requests/pending');
        const approved = allRequests.filter(r => r.status === 'APPROVED');

        if (!approved || approved.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 2rem; color: #9ca3af;">
                        <i class="fas fa-inbox"></i> No approved records yet
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        approved.forEach(request => {
            const date = new Date(request.updatedAt).toLocaleDateString();

            html += `
                <tr>
                    <td><strong>${request.requestId}</strong></td>
                    <td>Citizen ${request.citizenId}</td>
                    <td>${request.serviceType}</td>
                    <td>${date}</td>
                    <td><span class="status-badge status-approved">APPROVED</span></td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;
    } catch (error) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5">
                    <p style="color: var(--danger-red); text-align: center;">Error loading records</p>
                </td>
            </tr>
        `;
    }
}

async function loadRejectedRequests() {
    const tableBody = document.getElementById('rejected-table');

    try {
        const allRequests = await apiCall('GET', '/api/requests/pending');
        const rejected = allRequests.filter(r => r.status === 'REJECTED');

        if (!rejected || rejected.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 2rem; color: #9ca3af;">
                        <i class="fas fa-inbox"></i> No rejected records
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        rejected.forEach(request => {
            const date = new Date(request.updatedAt).toLocaleDateString();

            html += `
                <tr>
                    <td><strong>${request.requestId}</strong></td>
                    <td>Citizen ${request.citizenId}</td>
                    <td>${request.serviceType}</td>
                    <td>${date}</td>
                    <td>Incomplete Documents</td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;
    } catch (error) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5">
                    <p style="color: var(--danger-red); text-align: center;">Error loading records</p>
                </td>
            </tr>
        `;
    }
}

function openApprovalModal(requestId, requestIdValue) {
    const modal = new (window.bootstrap ? window.bootstrap.Modal : function() {}).prototype.constructor(
        document.getElementById('approvalModal')
    );
    
    document.getElementById('approval-request-id').textContent = 'Request ID: ' + requestIdValue;
    document.getElementById('approval-comments').value = '';
    
    // Store the requestId for later use
    window.pendingApprovalId = requestId;
    window.pendingApprovalValue = requestIdValue;
    
    const modalElement = document.getElementById('approvalModal');
    if (modalElement) {
        const bsModal = new bootstrap.Modal(modalElement);
        bsModal.show();
    }
}

function openRejectionModal(requestId, requestIdValue) {
    const modalElement = document.getElementById('rejectionModal');
    if (modalElement) {
        document.getElementById('rejection-request-id').textContent = 'Request ID: ' + requestIdValue;
        document.getElementById('rejection-reason').value = '';
        
        // Store the requestId for later use
        window.pendingRejectionId = requestId;
        window.pendingRejectionValue = requestIdValue;
        
        const bsModal = new bootstrap.Modal(modalElement);
        bsModal.show();
    }
}

async function confirmApproval() {
    const session = getSession();
    const comments = document.getElementById('approval-comments').value || 'Verified and approved.';
    const requestId = window.pendingApprovalId;

    if (!requestId) {
        alert('Error: Request ID not found');
        return;
    }

    try {
        const approvalData = {
            requestId: requestId,
            authorityId: session.userId,
            comments: comments,
            decision: 'APPROVED'
        };

        const response = await apiCall('POST', '/api/approvals/approve', approvalData);

        if (response && response.id) {
            alert('✅ Request approved successfully!\nBlockchain Hash: ' + (response.blockchainHash || 'hash_value'));
            
            // Close modal
            const modalElement = document.getElementById('approvalModal');
            const bsModal = bootstrap.Modal.getInstance(modalElement);
            if (bsModal) bsModal.hide();
            
            // Reload data
            loadPendingRequests();
            loadAuthorityDashboardData();
        } else {
            alert('❌ Error: Failed to approve request');
        }
    } catch (error) {
        alert('❌ Error: ' + error.message);
    }
}

async function confirmRejection() {
    const session = getSession();
    const reason = document.getElementById('rejection-reason').value;
    const requestId = window.pendingRejectionId;

    if (!requestId || !reason.trim()) {
        alert('Please enter a rejection reason');
        return;
    }

    try {
        const rejectionData = {
            requestId: requestId,
            authorityId: session.userId,
            comments: reason,
            decision: 'REJECTED'
        };

        const response = await apiCall('POST', '/api/approvals/reject', rejectionData);

        if (response && response.id) {
            alert('✅ Request rejected successfully!');
            
            // Close modal
            const modalElement = document.getElementById('rejectionModal');
            const bsModal = bootstrap.Modal.getInstance(modalElement);
            if (bsModal) bsModal.hide();
            
            // Reload data
            loadPendingRequests();
            loadAuthorityDashboardData();
        } else {
            alert('❌ Error: Failed to reject request');
        }
    } catch (error) {
        alert('❌ Error: ' + error.message);
    }
}

function logout() {
    clearSession();
    window.location.href = 'index.html';
}
    
    if (comments === null) {
        return; // User cancelled
    }

    try {
        const response = await rejectRequest(requestId, authorityId, comments);

        if (response.success) {
            alert('Request rejected successfully!');
            loadPendingRequests();
            loadAuthorityDashboardData();
        } else {
            alert('Error: ' + (response.message || 'Failed to reject'));
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
}

function logout() {
    clearSession();
    window.location.href = 'index.html';
}
