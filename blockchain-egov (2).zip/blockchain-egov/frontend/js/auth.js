// Authentication Functions

// Switch between login and register tabs
function switchTab(tab) {
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');
    const tabBtns = document.querySelectorAll('.tab-btn');

    if (tab === 'login') {
        loginSection.classList.add('active');
        registerSection.classList.remove('active');
        tabBtns[0].classList.add('active');
        tabBtns[1].classList.remove('active');
        clearMessages();
    } else {
        loginSection.classList.remove('active');
        registerSection.classList.add('active');
        tabBtns[0].classList.remove('active');
        tabBtns[1].classList.add('active');
        clearMessages();
    }
}

// Clear all messages
function clearMessages() {
    const messages = document.querySelectorAll('.message');
    messages.forEach(msg => {
        msg.classList.remove('show');
        msg.textContent = '';
    });
}

// Show message with type (success, error, info)
function showMessage(elementId, message, type = 'info') {
    const messageDiv = document.getElementById(elementId);
    messageDiv.textContent = message;
    messageDiv.className = `message show ${type}`;
    messageDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Validate form
function validateForm(form) {
    let isValid = true;
    
    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.classList.remove('is-invalid', 'is-valid');
        
        if (!input.checkValidity()) {
            isValid = false;
            input.classList.add('is-invalid');
        } else {
            input.classList.add('is-valid');
        }
    });

    return isValid;
}

// Validate password confirmation
function validatePasswordMatch() {
    const password = document.getElementById('register-password').value;
    const confirm = document.getElementById('register-password-confirm').value;
    const confirmInput = document.getElementById('register-password-confirm');

    if (password !== confirm && confirm !== '') {
        confirmInput.classList.add('is-invalid');
        return false;
    } else if (password === confirm && confirm !== '') {
        confirmInput.classList.add('is-valid');
        return true;
    }
    return true;
}

// Handle login
async function handleLogin(event) {
    event.preventDefault();
    const form = document.getElementById('login-form-el');
    
    if (!validateForm(form)) {
        showMessage('login-message', 'Please fill in all fields correctly', 'error');
        return;
    }

    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    const loginBtn = form.querySelector('button[type="submit"]');

    try {
        loginBtn.disabled = true;
        showMessage('login-message', 'Signing in...', 'info');
        
        const response = await loginUser(username, password);

        if (response.success) {
            // Store session
            localStorage.setItem('userId', response.userId);
            localStorage.setItem('username', response.username);
            localStorage.setItem('role', response.role);
            localStorage.setItem('walletAddress', response.walletAddress);
            
            showMessage('login-message', 'Login successful! Redirecting...', 'success');
            
            setTimeout(() => {
                // Redirect based on role
                if (response.role === 'CITIZEN') {
                    window.location.href = 'citizen-dashboard.html';
                } else if (response.role === 'AUTHORITY') {
                    window.location.href = 'authority-dashboard.html';
                } else {
                    window.location.href = 'index.html';
                }
            }, 1500);
        } else {
            showMessage('login-message', response.message || 'Invalid credentials. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Login Error:', error);
        showMessage('login-message', 'Login failed: ' + error.message, 'error');
    } finally {
        loginBtn.disabled = false;
    }
}

// Handle registration
async function handleRegister(event) {
    event.preventDefault();
    const form = document.getElementById('register-form-el');
    
    // Validate form
    if (!validateForm(form)) {
        showMessage('register-message', 'Please fill in all fields correctly', 'error');
        return;
    }

    // Validate password match
    if (!validatePasswordMatch()) {
        showMessage('register-message', 'Passwords do not match', 'error');
        return;
    }

    // Validate terms
    if (!document.getElementById('terms-agree').checked) {
        showMessage('register-message', 'You must agree to the Terms & Conditions', 'error');
        return;
    }

    const fullName = document.getElementById('register-fullname').value.trim();
    const username = document.getElementById('register-username').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const role = document.getElementById('register-role').value;
    const registerBtn = form.querySelector('button[type="submit"]');

    try {
        registerBtn.disabled = true;
        showMessage('register-message', 'Creating your account...', 'info');
        
        const response = await registerUser({
            fullName: fullName,
            username: username,
            email: email,
            password: password,
            role: role
        });

        if (response.success) {
            showMessage('register-message', 
                `✓ Account created successfully! Wallet: ${response.walletAddress}`, 
                'success');
            
            // Clear form
            form.reset();
            
            setTimeout(() => {
                switchTab('login');
                document.getElementById('login-username').focus();
            }, 2000);
        } else {
            showMessage('register-message', response.message || 'Registration failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Registration Error:', error);
        showMessage('register-message', 'Registration failed: ' + error.message, 'error');
    } finally {
        registerBtn.disabled = false;
    }
}

// Password confirmation validator
document.addEventListener('DOMContentLoaded', function() {
    const passwordConfirm = document.getElementById('register-password-confirm');
    if (passwordConfirm) {
        passwordConfirm.addEventListener('input', validatePasswordMatch);
    }

    // Auto-format username to alphanumeric
    const usernameInput = document.getElementById('register-username');
    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^a-zA-Z0-9_]/g, '');
        });
    }

    // Focus on first field
    document.getElementById('login-username').focus();
});

// Logout function
function logout() {
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    localStorage.removeItem('walletAddress');
    window.location.href = 'index.html';
}
