// API Configuration
const API_URL = 'http://localhost:8080/egov/api';

// Make API request
async function apiCall(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(`${API_URL}${endpoint}`, options);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Register User
async function registerUser(userData) {
    const params = new URLSearchParams({
        username: userData.username,
        password: userData.password,
        email: userData.email,
        fullName: userData.fullName,
        role: userData.role
    });

    return fetch(`${API_URL}/users/register?${params}`, { method: 'POST' })
        .then(res => res.json());
}

// Login User
async function loginUser(username, password) {
    const params = new URLSearchParams({
        username: username,
        password: password
    });

    return fetch(`${API_URL}/users/login?${params}`, { method: 'POST' })
        .then(res => res.json());
}

// Get User Info
async function getUserInfo(userId) {
    return fetch(`${API_URL}/users/${userId}`)
        .then(res => res.json());
}

// Submit Service Request
async function submitServiceRequest(citizenId, serviceType, description) {
    const params = new URLSearchParams({
        citizenId: citizenId,
        serviceType: serviceType,
        description: description
    });

    return fetch(`${API_URL}/requests/submit?${params}`, { method: 'POST' })
        .then(res => res.json());
}

// Get Citizen Requests
async function getCitizenRequests(citizenId) {
    return fetch(`${API_URL}/requests/citizen/${citizenId}`)
        .then(res => res.json());
}

// Get Pending Requests
async function getPendingRequests() {
    return fetch(`${API_URL}/requests/pending`)
        .then(res => res.json());
}

// Get Request Details
async function getRequestDetails(requestId) {
    return fetch(`${API_URL}/requests/${requestId}`)
        .then(res => res.json());
}

// Approve Request
async function approveRequest(requestId, authorityId, comments = '') {
    const params = new URLSearchParams({
        requestId: requestId,
        authorityId: authorityId,
        comments: comments
    });

    return fetch(`${API_URL}/approvals/approve?${params}`, { method: 'POST' })
        .then(res => res.json());
}

// Reject Request
async function rejectRequest(requestId, authorityId, comments = '') {
    const params = new URLSearchParams({
        requestId: requestId,
        authorityId: authorityId,
        comments: comments
    });

    return fetch(`${API_URL}/approvals/reject?${params}`, { method: 'POST' })
        .then(res => res.json());
}

// Get Approvals for Request
async function getApprovals(requestId) {
    return fetch(`${API_URL}/approvals/request/${requestId}`)
        .then(res => res.json());
}

// Store session data
function setSession(userData) {
    sessionStorage.setItem('userId', userData.userId);
    sessionStorage.setItem('username', userData.username);
    sessionStorage.setItem('role', userData.role);
    sessionStorage.setItem('walletAddress', userData.walletAddress);
}

// Get session data
function getSession() {
    return {
        userId: sessionStorage.getItem('userId'),
        username: sessionStorage.getItem('username'),
        role: sessionStorage.getItem('role'),
        walletAddress: sessionStorage.getItem('walletAddress')
    };
}

// Clear session
function clearSession() {
    sessionStorage.clear();
}

// Check if user is logged in
function isLoggedIn() {
    return sessionStorage.getItem('userId') != null;
}

// Redirect to appropriate dashboard based on role
function redirectToDashboard(role) {
    if (role === 'CITIZEN') {
        window.location.href = 'citizen-dashboard.html';
    } else if (role === 'AUTHORITY') {
        window.location.href = 'authority-dashboard.html';
    } else {
        window.location.href = 'index.html';
    }
}
