// Session Management Functions

// Get current user from session
function getUser() {
    return {
        userId: localStorage.getItem('userId'),
        username: localStorage.getItem('username'),
        role: localStorage.getItem('role'),
        walletAddress: localStorage.getItem('walletAddress')
    };
}

// Check if user is logged in
function isLoggedIn() {
    return localStorage.getItem('userId') !== null;
}

// Get user role
function getUserRole() {
    return localStorage.getItem('role');
}

// Get user ID
function getUserId() {
    return localStorage.getItem('userId');
}

// Set session after successful login
function setSession(userData) {
    localStorage.setItem('userId', userData.userId);
    localStorage.setItem('username', userData.username);
    localStorage.setItem('role', userData.role);
    localStorage.setItem('walletAddress', userData.walletAddress);
}

// Clear session on logout
function clearSession() {
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    localStorage.removeItem('walletAddress');
}

// Redirect to dashboard based on role
function redirectToDashboard(role) {
    if (role === 'CITIZEN') {
        window.location.href = 'citizen-dashboard.html';
    } else if (role === 'AUTHORITY') {
        window.location.href = 'authority-dashboard.html';
    } else if (role === 'ADMIN') {
        window.location.href = 'admin-dashboard.html';
    } else {
        window.location.href = 'index.html';
    }
}

// Check if user is authorized to access a page
function requireLogin() {
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Check if user has specific role
function requireRole(requiredRole) {
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return false;
    }

    const userRole = getUserRole();
    if (userRole !== requiredRole) {
        alert('You do not have permission to access this page');
        window.location.href = 'index.html';
        return false;
    }

    return true;
}

// Update user display in navbar
function updateUserDisplay() {
    const user = getUser();
    if (isLoggedIn()) {
        const userDisplay = document.getElementById('user-display');
        if (userDisplay) {
            userDisplay.textContent = `${user.username} (${user.role})`;
        }
    }
}

// Initialize session on page load
document.addEventListener('DOMContentLoaded', function() {
    updateUserDisplay();
});
