// Citizen Dashboard Functions - Enhanced Version

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return;
    }

    const session = getSession();
    document.getElementById('user-name').innerHTML = `<i class="fas fa-user-circle"></i> ${session.username}`;
    document.getElementById('wallet-address').textContent = session.walletAddress || '0x...';

    // Load initial dashboard data
    loadDashboardData();
});

function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.remove('active'));

    // Remove active class from all sidebar links  
    const sidebarLinks = document.querySelectorAll('.sidebar a');
    sidebarLinks.forEach(link => link.classList.remove('active'));

    // Show selected section
    const sectionId = sectionName === 'dashboard' ? 'dashboard-section' : sectionName + '-section';
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.add('active');
    }

    // Add active class to currently clicked link
    if (event && event.target && event.target.classList) {
        event.target.classList.add('active');
    }

    // Load data based on section
    if (sectionName === 'my-requests') {
        loadCitizenRequests();
    }
}

async function loadDashboardData() {
    const session = getSession();
    
    try {
        const requests = await apiCall('GET', `/api/requests/citizen/${session.userId}`);
        
        let totalRequests = requests.length || 0;
        let approvedCount = requests.filter(r => r.status === 'APPROVED').length || 0;
        let pendingCount = requests.filter(r => r.status === 'PENDING').length || 0;
        let rejectedCount = requests.filter(r => r.status === 'REJECTED').length || 0;

        document.getElementById('total-requests').textContent = totalRequests;
        document.getElementById('approved-count').textContent = approvedCount;
        document.getElementById('pending-count').textContent = pendingCount;
        document.getElementById('rejected-count').textContent = rejectedCount;
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

async function handleSubmitRequest(event) {
    event.preventDefault();
    
    const session = getSession();
    const serviceType = document.getElementById('service-type').value;
    const description = document.getElementById('description').value;
    const documentHash = document.getElementById('document-hash').value || 'LOCAL_DOC_HASH';
    const submitBtn = document.getElementById('submit-btn');
    const originalText = submitBtn.innerHTML;

    try {
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

        const requestData = {
            citizenId: session.userId,
            serviceType: serviceType,
            description: description,
            blockchainHash: documentHash
        };

        const response = await apiCall('POST', '/api/requests/submit', requestData);

        if (response && response.id) {
            // Show success message
            alert('✅ Request submitted successfully!\nRequest ID: ' + response.requestId + '\nTransaction Hash: ' + response.blockchainHash);
            
            // Reset form
            document.getElementById('service-request-form').reset();
            
            // Reload dashboard
            loadDashboardData();
            
            // Switch to my requests section
            setTimeout(() => {
                showSection('my-requests');
            }, 500);
        } else {
            alert('❌ Error: Failed to submit request');
        }
    } catch (error) {
        alert('❌ Error: ' + error.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
    }
}

async function loadCitizenRequests() {
    const session = getSession();
    const tableBody = document.getElementById('requests-table');

    try {
        const requests = await apiCall('GET', `/api/requests/citizen/${session.userId}`);

        if (!requests || requests.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 2rem; color: #9ca3af;">
                        <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 0.5rem;"></i><br>
                        No requests submitted yet
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        requests.forEach(request => {
            const statusClass = `status-${request.status.toLowerCase()}`;
            const statusBadge = `<span class="status-badge ${statusClass}">${request.status}</span>`;
            const date = new Date(request.createdAt).toLocaleDateString();

            html += `
                <tr>
                    <td><strong>${request.requestId}</strong></td>
                    <td>${request.serviceType}</td>
                    <td>${date}</td>
                    <td>${statusBadge}</td>
                    <td>
                        <button class="btn btn-primary btn-sm" onclick="viewRequestDetails('${request.requestId}')">
                            <i class="fas fa-eye"></i> View
                        </button>
                    </td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;
    } catch (error) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5">
                    <p style="color: var(--danger-red); text-align: center;">
                        <i class="fas fa-exclamation-circle"></i> Error loading requests
                    </p>
                </td>
            </tr>
        `;
        console.error('Error:', error);
    }
}

function viewRequestDetails(requestId) {
    alert('Request Details:\nID: ' + requestId + '\n\nFull details will be shown in an expanded view.');
}

async function handleVerifyRecord() {
    const requestId = document.getElementById('verify-request-id').value.trim();
    const resultDiv = document.getElementById('verification-result');
    const resultContent = document.getElementById('result-content');

    if (!requestId) {
        alert('Please enter a Request ID');
        return;
    }

    try {
        const request = await apiCall('GET', `/api/requests/requestId/${requestId}`);

        if (request) {
            if (request.status === 'APPROVED' && request.blockchainHash) {
                resultContent.innerHTML = `
                    <div style="background-color: #dcfce7; border-left: 4px solid var(--success-green); padding: 1rem; border-radius: 6px;">
                        <p style="margin: 0; color: var(--success-green); font-weight: 600;">
                            <i class="fas fa-check-circle"></i> Record Verified Successfully
                        </p>
                    </div>
                    <div style="margin-top: 1rem;">
                        <p><strong>Request ID:</strong> ${request.requestId}</p>
                        <p><strong>Service Type:</strong> ${request.serviceType}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-approved">APPROVED</span></p>
                        <p><strong>Submitted:</strong> ${new Date(request.createdAt).toLocaleString()}</p>
                        <p><strong>Blockchain Hash:</strong></p>
                        <code style="background-color: var(--light-gray); padding: 0.8rem; border-radius: 6px; display: block; word-break: break-all; font-size: 0.75rem;">
                            ${request.blockchainHash}
                        </code>
                        <p style="margin-top: 1rem; color: #6b7280; font-size: 0.9rem;">
                            ✓ This record is immutable and permanently stored on the blockchain
                        </p>
                    </div>
                `;
            } else if (request.status === 'PENDING') {
                resultContent.innerHTML = `
                    <div style="background-color: #fef08a; border-left: 4px solid var(--warning-yellow); padding: 1rem; border-radius: 6px;">
                        <p style="margin: 0; color: #92400e; font-weight: 600;">
                            <i class="fas fa-hourglass-half"></i> Request Pending
                        </p>
                    </div>
                    <p style="margin-top: 1rem;">Your request is under review. It will be available for verification once approved.</p>
                `;
            } else {
                resultContent.innerHTML = `
                    <div style="background-color: #fee2e2; border-left: 4px solid var(--danger-red); padding: 1rem; border-radius: 6px;">
                        <p style="margin: 0; color: var(--danger-red); font-weight: 600;">
                            <i class="fas fa-times-circle"></i> Request Rejected
                        </p>
                    </div>
                    <p style="margin-top: 1rem;">This request was rejected and cannot be verified on blockchain.</p>
                `;
            }
            resultDiv.style.display = 'block';
        } else {
            resultContent.innerHTML = `
                <div style="background-color: #fee2e2; border-left: 4px solid var(--danger-red); padding: 1rem; border-radius: 6px;">
                    <p style="margin: 0; color: var(--danger-red); font-weight: 600;">
                        <i class="fas fa-exclamation-circle"></i> Request Not Found
                    </p>
                </div>
            `;
            resultDiv.style.display = 'block';
        }
    } catch (error) {
        resultContent.innerHTML = `
            <div style="background-color: #fee2e2; border-left: 4px solid var(--danger-red); padding: 1rem; border-radius: 6px;">
                <p style="margin: 0; color: var(--danger-red); font-weight: 600;">
                    <i class="fas fa-exclamation-circle"></i> Error: ${error.message}
                </p>
            </div>
        `;
        resultDiv.style.display = 'block';
    }
}

function logout() {
    clearSession();
    window.location.href = 'index.html';
}
