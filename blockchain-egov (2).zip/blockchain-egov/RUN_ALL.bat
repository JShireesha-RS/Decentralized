@echo off
REM Decentralized E-Governance System - One Command Startup
REM This script starts both backend and frontend automatically

echo.
echo ====================================================
echo   Decentralized E-Governance System - Startup
echo ====================================================
echo.

REM Build the project
echo [1] Building project...
cd /d e:\blockchain-egov
call mvn clean compile -DskipTests

if errorlevel 1 (
    echo Build failed! Exiting...
    pause
    exit /b 1
)

echo [2] Build successful!
echo.
echo [3] Starting Backend (Spring Boot)...
echo.

REM Start backend in a new window
start cmd /k "cd /d e:\blockchain-egov && mvn spring-boot:run"

REM Wait for backend to start
echo [4] Waiting 5 seconds for backend to start...
timeout /t 5 /nobreak

echo.
echo [5] Starting Frontend Server...
echo.

REM Start frontend in a new window
start cmd /k "cd /d e:\blockchain-egov\frontend && python -m http.server 3000"

echo.
echo ====================================================
echo   SUCCESS! System is running
echo ====================================================
echo.
echo Backend: http://localhost:8080/egov
echo Frontend: http://localhost:3000
echo.
echo Opening in browser...
echo.

REM Wait a moment then open browser
timeout /t 3 /nobreak
start http://localhost:3000/index.html

echo.
echo Both windows will stay open. Close them when done.
echo.
pause
