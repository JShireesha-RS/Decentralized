# QUICK START GUIDE - Decentralized E-Governance System

## 5-Minute Setup

### Step 1: Build the Project
```bash
cd e:\blockchain-egov
mvn clean compile
```
✅ Expected: BUILD SUCCESS

### Step 2: Start Backend Server
```bash
mvn spring-boot:run
```
✅ Server runs on: http://localhost:8080/egov
✅ Database: H2 (auto-created)

### Step 3: Open Frontend in Browser
Open the `frontend/index.html` in a web browser
✅ Homepage: http://localhost:3000/index.html

---

## Testing the System

### Test Case 1: Register as Citizen

1. Go to **Login** page
2. Click **Register** tab
3. Fill form:
   - Full Name: John Citizen
   - Username: johncitizen
   - Email: john@example.com
   - Password: pass123
   - Role: **Citizen**
4. Click **Register**
5. ✅ Success message with wallet address

### Test Case 2: Register as Authority

1. Go to **Login** page
2. Click **Register** tab
3. Fill form:
   - Full Name: Jane Authority
   - Username: janeauth
   - Email: jane@govt.com
   - Password: auth123
   - Role: **Government Authority**
4. Click **Register**
5. ✅ Success message

### Test Case 3: Login and Submit Request

1. Go to **Login** page, click **Login** tab
2. Enter: `johncitizen` / `pass123`
3. Click **Login**
4. ✅ Redirects to Citizen Dashboard
5. Click **Submit Request**
6. Fill form:
   - Service Type: Certificate Issuance
   - Description: Birth Certificate Request
7. Click **Submit Request**
8. ✅ Request submitted successfully

### Test Case 4: Authority Reviews & Approves

1. Go to **Login** page, click **Login** tab
2. Enter: `janeauth` / `auth123`
3. Click **Login**
4. ✅ Redirects to Authority Dashboard
5. Click **Pending Requests**
6. View citizen's request
7. Click **Approve** button
8. Enter approval comments
9. ✅ Request approved and recorded on blockchain

### Test Case 5: Verify Record

1. Login as citizen
2. Click **Verify Record**
3. Enter the Request ID from submitted request
4. Click **Verify**
5. ✅ Shows blockchain verification status

---

## File Locations

### Backend Files
- Controllers: `src/main/java/com/gandham/egov/controller/`
- Services: `src/main/java/com/gandham/egov/service/`
- Models: `src/main/java/com/gandham/egov/model/`
- Config: `src/main/resources/application.properties`

### Frontend Files
- Pages: `frontend/*.html`
- Styles: `frontend/css/style.css`
- Scripts: `frontend/js/`

### Smart Contracts
- Contract: `smart-contracts/EGovernance.sol`

### Documentation
- Overview: `README.md`
- Report: `PROJECT_COMPLETION_REPORT.md`
- This Guide: `QUICK_START.md`

---

## Important URLs

```
Frontend:
- Home:     http://localhost:3000/index.html
- Login:    http://localhost:3000/login.html
- About:    http://localhost:3000/about.html

Backend API:
- Base:     http://localhost:8080/egov/api
- Users:    http://localhost:8080/egov/api/users
- Requests: http://localhost:8080/egov/api/requests
- Approvals:http://localhost:8080/egov/api/approvals

Database Console:
- H2:       http://localhost:8080/egov/h2-console
```

---

## API Testing with cURL

### Register User
```bash
curl -X POST "http://localhost:8080/egov/api/users/register?username=test&password=pass&email=test@test.com&fullName=Test User&role=CITIZEN"
```

### Login
```bash
curl -X POST "http://localhost:8080/egov/api/users/login?username=test&password=pass"
```

### Submit Request
```bash
curl -X POST "http://localhost:8080/egov/api/requests/submit?citizenId=1&serviceType=CERTIFICATE&description=Test Request"
```

### Get Pending Requests
```bash
curl "http://localhost:8080/egov/api/requests/pending"
```

### Approve Request
```bash
curl -X POST "http://localhost:8080/egov/api/approvals/approve?requestId=1&authorityId=2&comments=Approved"
```

---

## Troubleshooting

### Problem: Port 8080 already in use
**Solution**: Change port in `application.properties`
```properties
server.port=8081
```

### Problem: Database errors
**Solution**: H2 uses in-memory database that auto-creates. Restart application if needed.

### Problem: Cannot connect to API
**Solution**: Ensure backend is running with `mvn spring-boot:run`

### Problem: Frontend not loading
**Solution**: Serve frontend with `python -m http.server 3000` or open files directly in browser

---

## Key Features to Test

- ✅ User Registration (Citizen & Authority)
- ✅ Login with credentials
- ✅ Submit service request (3 types)
- ✅ View pending requests (authority)
- ✅ Approve/Reject requests
- ✅ Verify records on blockchain
- ✅ View transaction history
- ✅ Dashboard statistics

---

## Demo Accounts

| Role | Username | Password |
|------|----------|----------|
| Citizen | citizen1 | pass123 |
| Authority | auth1 | auth123 |

*Note: Create accounts through registration for live testing*

---

## Support Documents

1. **README.md** - Complete project documentation
2. **PROJECT_COMPLETION_REPORT.md** - Detailed implementation report
3. **This File** - Quick reference guide

---

**Last Updated**: February 6, 2025
**Version**: 1.0.0
**Status**: Ready for Testing
