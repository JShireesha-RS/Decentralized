# Testing Guide & Demo Scenarios
## Decentralized E-Governance System

---

## 🧪 End-to-End Testing Procedures

### Prerequisites
- Backend running on `http://localhost:8080/egov`
- Frontend running on `http://localhost:3000`
- Browser: Chrome, Firefox (latest)
- No logins should be active (clear localStorage)

---

## TEST 1: User Registration & Login Flow

### Test 1.1: Citizen Registration
**Steps:**
1. Open `http://localhost:3000/login.html`
2. Click "Register as Citizen"
3. Fill form:
   ```
   Full Name: Test Citizen
   Email: testcitizen@email.com
   Mobile: 9999888877
   Password: TestPass@123
   Confirm: TestPass@123
   Role: CITIZEN
   ```
4. Click "Register"

**Expected Result:** ✅
- Success message appears
- Page redirects to login
- User can login with new credentials

**Security Check:**
- Password should be hashed (verify via H2 console: `SELECT password FROM users WHERE email='testcitizen@email.com'`)
- Hash is long Base64 string, not plaintext
- Same password produces different hash each time (due to salt)

---

### Test 1.2: Officer Registration
**Steps:**
1. Open `http://localhost:3000/login.html`
2. Click "Register as Officer"
3. Fill form:
   ```
   Full Name: Test Officer
   Email: testofficer@gov.in
   Mobile: 8888777766
   Password: OfficerTest@123
   Confirm: OfficerTest@123
   Role: AUTHORITY
   ```
4. Click "Register"

**Expected Result:** ✅
- Success message
- Unique wallet address generated (UUID format)
- Can view wallet address in H2 console

---

### Test 1.3: Login Verification
**Steps:**
1. Register citizen with email: `citizen@test.com`
2. Try login with wrong password
3. Verify error message appears
4. Try login with correct password
5. Verify dashboard loads

**Expected Result:** ✅
- Wrong password: Error message, not logged in
- Correct password: Dashboard loads, user name shown
- Session stored in browser localStorage
- Wallet address displayed

**Security Check:**
```javascript
// In browser console
getSession()
// Should show: {userId: 1, username: "...", role: "CITIZEN", walletAddress: "0x..."}
```

---

## TEST 2: Citizen Request Submission

### Test 2.1: Submit Income Certificate Request
**Steps:**
1. Login as citizen
2. Click "Submit New Request" in sidebar
3. Fill form:
   ```
   Service Type: Income Certificate
   Description: Need certificate for bank loan application. Annual income 5 lakh.
   Document Hash: (leave empty or enter test hash)
   ```
4. Click "Submit Request"

**Expected Result:** ✅
- Blockchain confirmation popup
- Success message with Request ID: `REQ_2024_XXXXX`
- Blockchain Hash displayed: `0x...`
- Dashboard updated with stat (Total Requests: 1)
- Request appears in "My Requests" table with status `PENDING` 🟡

**Database Check:**
```sql
SELECT * FROM service_requests ORDER BY id DESC LIMIT 1;
-- Should show: requestId, citizenId, serviceType, status='PENDING'
```

---

### Test 2.2: Submit Multiple Requests
**Steps:**
1. Submit 3 different requests:
   - Land Record - "Property verification needed"
   - Birth Certificate - "Official document needed"
   - Caste Certificate - "For scholarship application"

**Expected Result:** ✅
- All 3 requests visible in "My Requests" table
- Dashboard shows: Total Requests: 3, Pending: 3
- Each has unique Request ID

---

### Test 2.3: Request Status Filtering
**Steps:**
1. Go to "My Requests"
2. Note all statuses (should all be PENDING initially)
3. Verify column headers: Request ID, Service Type, Submitted Date, Status, Actions

**Expected Result:** ✅
- Status badges are yellow 🟡 (PENDING)
- Dates formatted as DD/MM/YYYY
- View button available for each request

---

## TEST 3: Officer Dashboard & Approvals

### Test 3.1: Officer Login & Dashboard
**Steps:**
1. Logout from citizen account
2. Login as officer: `officer1@gov.in` / `OfficerPass@123`
3. Verify dashboard loads

**Expected Result:** ✅
- Officer Dashboard shown (different from citizen dashboard)
- Navbar shows "Officer Portal" with gavel icon 👨‍⚖️
- Sidebar shows: Dashboard, Pending, Approved, Rejected
- Stats show: Pending count, Today's actions
- Quick access buttons visible

**Session Check:**
```javascript
getSession()
// Should show: role: "AUTHORITY"
```

---

### Test 3.2: View Pending Requests
**Steps:**
1. Click "Pending" in sidebar
2. View list of pending requests from citizens

**Expected Result:** ✅
- Table shows all PENDING requests
- Columns: Request ID, Citizen Name, Service Type, Submitted Date, Actions
- Each request has "Approve" and "Reject" buttons (green and red)
- Shows all 3 requests submitted in Test 2.2

---

### Test 3.3: Approve Request
**Steps:**
1. Click "Approve" button for first request
2. Modal popup appears
3. Enter comments: "Income verified, documents complete."
4. Click "Confirm Approval"

**Expected Result:** ✅
- Blockchain transaction simulated
- Success message with transaction hash
- Request status changes from `PENDING` 🟡 to `APPROVED` 🟢
- Appears in "Approved" tab

**Database Check:**
```sql
SELECT * FROM approvals WHERE request_id = (SELECT id FROM service_requests WHERE request_id='REQ_2024_...');
-- Should show: status='APPROVED', officer wallet address, timestamp
```

---

### Test 3.4: Reject Request  
**Steps:**
1. Click "Reject" for another request
2. Modal appears with "Rejection Reason" field
3. Enter: "Documents incomplete. Please resubmit with full address proof."
4. Click "Confirm Reject"

**Expected Result:** ✅
- Request status changes to `REJECTED` 🔴
- Appears in "Rejected" tab
- Shows rejection reason
- Citizen receives notification (would be email in production)

---

## TEST 4: Citizen Verification

### Test 4.1: Verify Approved Request
**Steps:**
1. Logout officer, login as citizen
2. Click "Verify Record" in sidebar
3. Enter approved request ID (from Test 3.3)
4. Click "Verify Record"

**Expected Result:** ✅
- Shows: "Record Verified Successfully" ✓
- Displays request details
- Shows blockchain hash (immutable proof)
- Message: "This record is immutable and permanently stored on the blockchain"

**Security Check:**
- Hash cannot be changed
- Timestamp is fixed
- Officer wallet address visible (proves who approved)

---

### Test 4.2: Verify Pending Request
**Steps:**
1. Enter pending request ID
2. Click "Verify Record"

**Expected Result:** ✅
- Shows: "Request Pending" ⏳
- Message: "Your request is under review. It will be available for verification once approved."
- No blockchain hash shown (not approved yet)

---

### Test 4.3: Verify Rejected Request
**Steps:**
1. Enter rejected request ID
2. Click "Verify Record"

**Expected Result:** ✅
- Shows: "Request Rejected" 🔴
- Message: "This request was rejected and cannot be verified on blockchain."

---

## TEST 5: Multiple Officer Workflow

### Test 5.1: Officer Conflict Handling
**Steps:**
1. Login as Officer 1 (priya.sharma)
2. Approve a request with comment: "Approved by Officer 1"
3. Logout, Login as Officer 2 (arjun.singh)
4. Try to approve same request

**Expected Result:** ✅
- Officer 2 sees request already approved
- Button disabled (already processed)
- Cannot double-approve
- Audit log shows both officers' wallets

---

## TEST 6: Role-Based Access Control (RBAC)

### Test 6.1: Citizen Cannot Access Officer Dashboard
**Steps:**
1. Login as citizen
2. Try to access `/egov/api/requests/pending` (officer endpoint)
3. Or manually visit authority-dashboard.html

**Expected Result:** ✅
- Request blocked with 403 FORBIDDEN
- Frontend redirects to home page
- Message: "Access denied. Authority access only."

---

### Test 6.2: Officer Cannot Submit as Citizen
**Steps:**
1. Login as officer
2. Try to click "Submit Request"
3. Check if form appears

**Expected Result:** ✅
- Officer dashboard doesn't have submit form
- If they try API directly: 403 FORBIDDEN
- Error: "Only citizens can submit requests"

---

## TEST 7: Security Tests

### Test 7.1: Password Hashing Verification
**Steps:**
1. Open H2 Console: `http://localhost:8080/egov/h2-console`
2. Login (usually no password needed)
3. Run query:
   ```sql
   SELECT id, email, password FROM users LIMIT 5;
   ```

**Expected Result:** ✅
- Password column shows long Base64 strings
- Example: `rO2ZYJ3+jkYfK...=` (NOT plaintext)
- Same password from different users = different hash

---

### Test 7.2: Audit Trail Verification
**Steps:**
1. Open H2 Console
2. Run query:
   ```sql
   SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 10;
   ```

**Expected Result:** ✅
- Shows recent actions: LOGIN, SUBMIT_REQUEST, APPROVE_REQUEST
- Each log has: userId, username, action, timestamp, walletAddress
- Complete audit history available

---

### Test 7.3: Blockchain Hash Immutability
**Steps:**
1. Approve a request (save blockchain hash)
2. Try to manually update the hash via H2
3. Try to verify the record

**Expected Result:** ✅
- If you manually change hash, verification fails
- Blockchain-based verification catches tampering
- Hash mismatch indicates fraud

---

## TEST 8: Data Validation

### Test 8.1: Invalid Service Request Submission
**Steps:**
1. Try to submit request with:
   - Empty service type
   - Empty description
   - Invalid email format

**Expected Result:** ✅
- Form shows error messages
- Request not submitted
- Page shows validation errors

---

### Test 8.2: Weak Password Rejection
**Steps:**
1. Try to register with password: `123`
2. Try to register with password: `Password`

**Expected Result:** ✅
- Form rejects password < 8 characters
- Form requires at least one special character
- Shows message: "Password must be at least 8 characters with special characters"

---

## TEST 9: UI/UX Responsiveness

### Test 9.1: Mobile Responsiveness
**Steps:**
1. Open dashboard on desktop
2. Resize browser to mobile width (375px)
3. Test on actual mobile device

**Expected Result:** ✅
- Sidebar collapses to icons
- Tables become scrollable
- Buttons remain accessible
- Font sizes readable
- No horizontal scroll needed

---

### Test 9.2: Dashboard Loading States
**Steps:**
1. Click "Refresh" button while data loads
2. Submit form and watch for loading indicator
3. Approve request and watch for confirmation

**Expected Result:** ✅
- Loading spinners appear during API calls
- Buttons show loading state
- Form submit button disabled during submission
- User feedback on all actions

---

## TEST 10: Multi-User Scenarios

### Test 10.1: Concurrent Citizens
**Steps:**
1. Open two browser windows (private mode)
2. Citizen 1: Login as ramesh@gmail.com
3. Citizen 2: Login as anita.sharma@gmail.com
4. Both submit requests
5. Switch to officer dashboard
6. Verify both requests visible

**Expected Result:** ✅
- Both requests in pending list
- Officer can distinguish between citizens
- Approving one doesn't affect other
- Each citizen sees only their requests

---

## TEST 11: Session Management

### Test 11.1: Session Timeout
**Steps:**
1. Login as user
2. Manually clear localStorage in console: `localStorage.clear()`
3. Try to access dashboard

**Expected Result:** ✅
- Page redirects to login
- Dashboard not accessible
- Error message: "Please login first"

---

### Test 11.2: Cross-Tab Session Sync
**Steps:**
1. Login in Tab 1
2. Open dashboard in Tab 2
3. Logout in Tab 1
4. Try to navigate in Tab 2

**Expected Result:** ✅
- Session works independently (can improve with storage events)
- Logout in one tab doesn't affect other (currently)

---

## 📊 Test Summary Checklist

### Authentication ✅
- [ ] Citizen registration works
- [ ] Officer registration works
- [ ] Login with correct password works
- [ ] Login with wrong password fails
- [ ] Passwords are hashed (not plaintext)
- [ ] Session stored in browser

### Authorization ✅
- [ ] Citizen cannot access officer dashboard
- [ ] Officer cannot submit as citizen
- [ ] Citizens can only see own requests
- [ ] Officers can view all pending requests

### Functionality ✅
- [ ] Submit request works
- [ ] Request appears in dashboard
- [ ] Officer can approve
- [ ] Officer can reject
- [ ] Approval status updated
- [ ] Citizen can verify record
- [ ] Blockchain hash displayed
- [ ] Multiple requests handled

### Security ✅
- [ ] Passwords hashed in database
- [ ] Audit log created for each action
- [ ] Role validation on backend
- [ ] Input validation works
- [ ] Error messages don't expose details

### UI/UX ✅
- [ ] Professional design with colors
- [ ] Status badges (green/yellow/red)
- [ ] Loading indicators
- [ ] Responsive on mobile
- [ ] Tables and cards layout
- [ ] Icons and visual hierarchy
- [ ] Modal dialogs for actions

### Performance ✅
- [ ] Dashboard loads within 2 seconds
- [ ] API responses under 1 second
- [ ] No console errors
- [ ] Smooth animations
- [ ] No memory leaks (check browser DevTools)

---

## 🎯 Demo Flow (5-Minute Version)

### 1. Registration (1 min)
- Show registration page
- Register new citizen
- Show password is hashed in database

### 2. Citizen Request (1 min)
- Login as citizen
- Submit Income Certificate request
- Show request in dashboard

### 3. Officer Approval (1.5 min)
- Logout, login as officer
- Show pending request
- Approve with comments
- Show blockchain hash

### 4. Verification (1 min)
- Logout, login as citizen
- Verify approved request on blockchain
- Show immutable hash

### 5. Security Explanation (0.5 min)
- Open H2 console, show hashed password
- Explain RBAC
- Mention audit trail
- Discuss blockchain immutability

---

## Troubleshooting

### Issue: Login fails
- Check backend is running: `mvn spring-boot:run`
- Check database connection in H2 console
- Clear browser cache and localStorage

### Issue: Requests not appearing
- Check API endpoint in console (Network tab)
- Verify user ID is correct session
- Check backend logs for errors

### Issue: Blockchain hash empty
- Hash should be generated on request submission
- Check database has blockchainHash value
- Verify smart contract integration

### Issue: Modal not closing
- Check Bootstrap JS loaded
- Verify Modal ID matches button target
- Check browser console for errors

---

## Performance Benchmarks

| Operation | Target | Acceptable |
|-----------|--------|-----------|
| Page load | < 2s | < 3s |
| API response | < 500ms | < 1s |
| Registration | < 1s | < 2s |
| Submit request | < 1.5s | < 3s |
| Approve request | < 1.5s | < 3s |
| Query verification | < 200ms | < 500ms |

---

## Success Criteria

✅ **System passes all tests** if:
1. All 6 user flows work (register, login, submit, approve, verify, logout)
2. Role-based access control enforced
3. Passwords hashed (verified in database)
4. Audit log complete
5. UI professional and responsive
6. No console errors
7. All security measures demonstrated
8. Blockchain hashes immutable

---

Good luck with your demo! 🚀
